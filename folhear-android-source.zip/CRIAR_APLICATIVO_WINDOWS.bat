@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo Compilando o Folhear para Windows (Tauri/NSIS)...
echo Exige Node.js, Rust, Visual Studio C++ Build Tools e WebView2.
echo.
if not exist "node_modules" call npm install
if errorlevel 1 goto :erro
call npm test
if errorlevel 1 goto :erro
call npm run desktop:build
if errorlevel 1 goto :erro
echo.
echo Instalador gerado em src-tauri\target\release\bundle\nsis\
pause
exit /b 0
:erro
echo.
echo Erro durante compilacao; leia as mensagens acima.
pause
exit /b 1

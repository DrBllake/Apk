@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title FOLHEAR - Compilar APK Android

echo ==================================================
echo          FOLHEAR - APK PARA ANDROID
echo ==================================================
echo.
echo Este arquivo gera um APK de TESTE ARM64 no Windows.
echo E preciso ter Android Studio + SDK/NDK + Rust + Node.
echo.

where npm >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js / npm nao encontrado.
  goto :fail
)
where rustup >nul 2>&1
if errorlevel 1 (
  echo ERRO: Rust / rustup nao encontrado.
  goto :fail
)

if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platforms" (
  echo ERRO: Android SDK nao encontrado em "%ANDROID_HOME%".
  echo Instale o Android Studio e o SDK Manager. Veja LEIA_PRIMEIRO_ANDROID.txt.
  goto :fail
)
if not defined NDK_HOME (
  for /f "delims=" %%N in ('dir /b /ad /o-n "%ANDROID_HOME%\ndk" 2^>nul') do if not defined NDK_HOME set "NDK_HOME=%ANDROID_HOME%\ndk\%%N"
)
if not exist "%NDK_HOME%" (
  echo ERRO: Android NDK nao encontrado. Instale NDK Side by side no Android Studio.
  goto :fail
)
if not defined JAVA_HOME (
  if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
)
if not exist "%JAVA_HOME%\bin\java.exe" (
  echo ERRO: JAVA_HOME nao encontrado. Instale o JDK do Android Studio.
  goto :fail
)
set "PATH=%JAVA_HOME%\bin;%PATH%"
echo.
echo ANDROID_HOME=%ANDROID_HOME%
echo NDK_HOME=%NDK_HOME%
echo JAVA_HOME=%JAVA_HOME%
echo.

call npm install --no-audit --no-fund
if errorlevel 1 goto :fail
call rustup target add aarch64-linux-android
if errorlevel 1 goto :fail
call npm test
if errorlevel 1 goto :fail
if not exist "src-tauri\gen\android\gradlew.bat" (
  call npx tauri android init --ci
  if errorlevel 1 goto :fail
)
call npx tauri android build --apk --debug --target aarch64 --ci
if errorlevel 1 goto :fail

echo.
echo ===== APK(S) GERADO(S) =====
for /r "src-tauri\gen\android\app\build\outputs\apk" %%A in (*.apk) do echo %%~fA
echo.
echo Este e um APK de testes, nao uma versao assinada para a Play Store.
pause
exit /b 0

:fail
echo.
echo Falha na preparacao ou compilacao. Consulte LEIA_PRIMEIRO_ANDROID.txt.
pause
exit /b 1

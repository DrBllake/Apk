@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Folhear - Aplicativo Windows
echo.
echo =============================================
echo         FOLHEAR - APLICATIVO WINDOWS
echo =============================================
echo.
if exist "src-tauri\target\release\folhear.exe" (
  start "" "src-tauri\target\release\folhear.exe"
  exit /b 0
)
where node >nul 2>&1
if errorlevel 1 (
  echo Falta o Node.js. Instale https://nodejs.org/
  goto :erro
)
where cargo >nul 2>&1
if errorlevel 1 (
  echo Falta o Rust para executar o app Tauri.
  echo Instale em https://rustup.rs/ e reinicie o terminal.
  echo Veja tambem as ferramentas C++ no LEIA_PRIMEIRO_WINDOWS.txt.
  goto :erro
)
if not exist "node_modules" (
  echo Instalando dependencias pela primeira vez...
  call npm install
  if errorlevel 1 goto :erro
)
echo Iniciando o Folhear em uma janela de aplicativo, sem navegador...
call npm run desktop:dev
if errorlevel 1 goto :erro
exit /b 0
:erro
echo.
echo Nao foi possivel iniciar. Leia a mensagem acima.
pause
exit /b 1

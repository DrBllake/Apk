# Folhear — Plano de marcos e situação (09/11/2026)

| Etapa | Entrega | Situação |
|---|---|---|
| M1 | PDF local, duas páginas, arraste, som, salvar página, app Tauri | Base validada pelo usuário; CSS `position:absolute` preservado |
| M2.1 | Lombada, capa física, espessura dinâmica, sombras | Testado pelo usuário |
| M2.2 | Livro maior, modo imersivo, redimensionamento | Testado pelo usuário |
| M2.3 | Abrir/fechar capa sem modificar StPageFlip | Base usada na atualização; refinado título, imagem e clique na capa |
| M2.4 | Ambientes, tom do papel, sombra e tamanho ajustáveis | Implementado, aguardando teste Windows |
| M3.1 | Biblioteca offline local, capas, importação múltipla | Implementado, aguardando teste Windows |
| M3.2 | Categorias, favoritos, filtros, pesquisa e ordenação | Implementado, aguardando teste Windows |
| M3.3 | Marcadores, índice e busca textual do PDF | Implementado, aguardando teste Windows |
| M3.4 | Ícone, NSIS, associação PDF, fluxo de build | Configurado, ainda sem instalador Windows compilado neste ambiente |

Esta versão une todas as etapas restantes. **Não considerar concluída sem testar no Windows.**


## Android 0.4.0 — primeira adaptação
- Layout responsivo e página única no celular; tablets/paisagem ampla com duas páginas.
- Tauri v2: configuração Android isolada e script para gerar APK ARM64 de desenvolvimento.
- CI GitHub Actions prepara um APK de teste para baixar como artefato.
- Compatibilidade e APK dependem de validação na WebView real; nenhum pacote binário foi compilado neste ambiente.

# Folhear 0.4.0 — Windows + Android (projeto de teste)

Esta é a base Folhear 0.3.1 (capa personalizada limpa) com a primeira adaptação para Android.

**Windows:** mantenha seu Folhear atual; não é necessário substituir a instalação que já funciona. Este ZIP é um projeto independente.

**Android:** leia `LEIA_PRIMEIRO_ANDROID.txt`. O projeto foi preparado para gerar um **APK de teste ARM64** usando Tauri v2. Este pacote é o código-fonte — não é um arquivo APK já compilado.

## Recursos da adaptação Android

- Interface adaptável a telas pequenas e controles de toque.
- Uma página por vez em celulares/telas estreitas, duas em telas grandes.
- Rotação da tela com remontagem do livro na dimensão real.
- Capas personalizadas, marcadores, índice, busca, configurações e biblioteca offline existentes.
- StPageFlip preservado; CSS `.book-page { position: absolute; }` intocado.
- Compilação por `GERAR_APK_ANDROID.bat` no Windows ou GitHub Actions (`.github/workflows/compilar-android.yml`).

## Testes

`npm install` e `npm test`; para verificar o frontend: `npm run build`.

Não foi possível compilar e abrir um APK neste ambiente (Android SDK/NDK indisponível). O seletor de arquivos, a permanência do armazenamento e o folhear por toque ainda requerem testes em aparelho real.

## Importante

O armazenamento Android (IndexedDB/WebView) é separado do Windows e **não sincroniza livros**. Desinstalar ou limpar os dados do aplicativo apaga os PDFs e metadados importados no Android. Guarde seus arquivos originais.

Referências oficiais: https://tauri.app/start/prerequisites/ e https://tauri.app/distribute/google-play/.

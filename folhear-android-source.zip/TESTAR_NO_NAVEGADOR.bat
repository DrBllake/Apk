@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "node_modules" call npm install
if errorlevel 1 goto :erro
echo Modo opcional para testes tecnicos em http://127.0.0.1:1420
start "" "http://127.0.0.1:1420"
call npm run dev
exit /b %errorlevel%
:erro
pause
exit /b 1

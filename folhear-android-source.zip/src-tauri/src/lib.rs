use tauri::ipc::Response;
use std::path::PathBuf;

// Apenas o caminho recebido como argumento de abertura do SO pode ser lido.
// Nenhum comando recebe caminhos arbitrários vindos do PDF ou da interface.
fn startup_pdf() -> Option<PathBuf> {
    std::env::args_os().skip(1).map(PathBuf::from).find(|path| {
        path.is_file() && path.extension().and_then(|s| s.to_str())
            .is_some_and(|ext| ext.eq_ignore_ascii_case("pdf"))
    })
}

#[tauri::command]
fn startup_pdf_name() -> Option<String> {
    startup_pdf()?.file_name()?.to_str().map(str::to_owned)
}

#[tauri::command]
fn startup_pdf_bytes() -> Result<Response, String> {
    let path = startup_pdf().ok_or_else(|| "Nenhum PDF foi recebido do Windows".to_string())?;
    let bytes = std::fs::read(path).map_err(|error| format!("Falha ao abrir PDF: {error}"))?;
    Ok(Response::new(bytes))
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![startup_pdf_name, startup_pdf_bytes])
        .run(tauri::generate_context!())
        .expect("Falha ao iniciar o Folhear");
}

export type SceneName = 'classic' | 'wood' | 'night';
export type PaperTone = 'original' | 'warm' | 'sepia';
export type Appearance = { scene: SceneName; paper: PaperTone; shadow: number; size: number; };
export const DEFAULT_APPEARANCE: Appearance = { scene: 'classic', paper: 'original', shadow: 55, size: 100 };
const KEY = 'folhear:appearance:v1';
export function validateAppearance(input: unknown): Appearance {
  const p = (input && typeof input === 'object') ? input as Partial<Appearance> : {};
  const clamp = (v: unknown, min: number, max: number, fallback: number) => typeof v === 'number' && Number.isFinite(v) ? Math.max(min, Math.min(max, Math.round(v))) : fallback;
  return {
    scene: p.scene === 'wood' || p.scene === 'night' ? p.scene : 'classic',
    paper: p.paper === 'warm' || p.paper === 'sepia' ? p.paper : 'original',
    shadow: clamp(p.shadow, 0, 100, 55),
    size: clamp(p.size, 65, 100, 100),
  };
}
export function loadAppearance(): Appearance {
  try { const saved = localStorage.getItem(KEY); return saved ? validateAppearance(JSON.parse(saved)) : { ...DEFAULT_APPEARANCE }; }
  catch { return { ...DEFAULT_APPEARANCE }; }
}
export function saveAppearance(appearance: Appearance): void {
  try { localStorage.setItem(KEY, JSON.stringify(validateAppearance(appearance))); } catch { /* quota */ }
}

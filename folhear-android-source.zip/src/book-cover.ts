/**
 * M2.3 — capa animada EXTERNA ao StPageFlip.
 * Não toca no HTML das páginas, nem nos transforms, clip-path ou z-index das folhas.
 */
export function coverDisplayTitle(fileName: string): string {
  const cleaned = fileName
    .replace(/\.pdf$/i, '')
    .replace(/[_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return (cleaned.replace(/(?:\s+v\d+(?:[.-]\d+)*(?:\s*\(\d+\))?)$/i, '')
    .replace(/\s*\(\d+\)$/g, '').trim() || 'Meu livro').slice(0, 90);
}

export const COVER_ANIMATION_MS = 820;

export type CoverLayer = {
  close: () => Promise<void>;
  open: () => Promise<void>;
  dispose: () => void;
  isBusy: () => boolean;
  update: (title: string, image?: string) => void;
};

/**
 * Desenha uma capa de couro FECHADA em um elemento irmão do cenário do livro.
 * Enquanto fechada, a capa intercepta os gestos; reabrir revela o mesmo PageFlip.
 */
export function createCoverLayer(
  mount: HTMLElement,
  pageWidth: number,
  pageHeight: number,
  fileName: string,
  initiallyClosed: boolean,
  requestOpen: () => void,
  displayTitle?: string,
  imageUrl?: string,
): CoverLayer {
  const stage = document.createElement('div');
  stage.className = `book-cover-screen ${initiallyClosed ? 'is-closed' : 'is-open'}`;
  stage.setAttribute('aria-label', 'Capa do livro');

  const book = document.createElement('div');
  book.className = 'closed-book';
  book.style.width = `${pageWidth}px`;
  book.style.height = `${pageHeight}px`;
  book.setAttribute('role', 'button');
  book.tabIndex = 0;
  book.setAttribute('aria-label', `Abrir ${displayTitle || coverDisplayTitle(fileName)}`);
  book.title = 'Clique na capa para abrir o livro';

  const pages = document.createElement('div');
  pages.className = 'closed-book-pages';
  pages.setAttribute('aria-hidden', 'true');
  const cover = document.createElement('div');
  cover.className = 'closed-book-front';
  const trim = document.createElement('div');
  trim.className = 'closed-book-trim';
  const ornament = document.createElement('span');
  ornament.className = 'closed-book-ornament';
  ornament.textContent = '❦';
  ornament.setAttribute('aria-hidden', 'true');
  const eyebrow = document.createElement('span');
  eyebrow.className = 'closed-book-eyebrow';
  eyebrow.textContent = 'BIBLIOTECA FOLHEAR';
  const title = document.createElement('strong');
  title.className = 'closed-book-title';
  title.textContent = displayTitle || coverDisplayTitle(fileName);
  const action = document.createElement('button');
  action.type = 'button';
  action.className = 'closed-book-open';
  action.textContent = 'Abrir livro';
  action.setAttribute('aria-label', `Abrir ${displayTitle || coverDisplayTitle(fileName)}`);
  // Com capa personalizada, mostrar a arte ORIGINAL, sem filtro escuro
  // e sem textos/ornamentos duplicados por cima.
  if (imageUrl) { cover.style.backgroundImage = `url(${JSON.stringify(imageUrl)})`; cover.classList.add('has-cover-image'); }
  action.addEventListener('click', () => requestOpen());
  book.addEventListener('click', (event) => {
    if (event.target !== action && stage.classList.contains('is-closed')) requestOpen();
  });
  // A capa inteira também pode ser aberta por Enter/Espaço (acessibilidade).
  book.addEventListener('keydown', (event) => {
    if (event.target === book && (event.key === 'Enter' || event.key === ' ') && stage.classList.contains('is-closed')) {
      event.preventDefault();
      requestOpen();
    }
  });
  trim.append(ornament, eyebrow, title, action);
  cover.appendChild(trim);
  book.append(pages, cover);
  stage.appendChild(book);
  mount.appendChild(stage);

  let busy = false;
  let destroyed = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let finish: (() => void) | null = null;

  function transition(next: 'open' | 'closed'): Promise<void> {
    if (destroyed || busy) return Promise.resolve();
    busy = true;
    stage.className = `book-cover-screen is-${next === 'closed' ? 'closing' : 'opening'}`;
    action.disabled = true;
    return new Promise<void>((resolve) => {
      finish = resolve;
      // Mesmo sem animationend (reduzir movimento ou troca de janela), finaliza.
      timer = setTimeout(() => {
        timer = undefined;
        stage.className = `book-cover-screen is-${next}`;
        action.disabled = false;
        busy = false;
        finish = null;
        resolve();
      }, window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : COVER_ANIMATION_MS);
    });
  }

  return {
    close: () => transition('closed'),
    open: () => transition('open'),
    dispose: () => {
      destroyed = true;
      clearTimeout(timer);
      finish?.(); // não deixa promessa pendente em reconstrução da janela
      finish = null;
      stage.remove();
    },
    isBusy: () => busy,
    update: (newTitle: string, image?: string) => {
      title.textContent = newTitle;
      action.setAttribute('aria-label', `Abrir ${newTitle}`);
      book.setAttribute('aria-label', `Abrir ${newTitle}`);
      cover.classList.toggle('has-cover-image', Boolean(image));
      cover.style.backgroundImage = image ? `url(${JSON.stringify(image)})` : "";
    },
  };
}

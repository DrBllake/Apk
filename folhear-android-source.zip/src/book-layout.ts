/** Calcula dimensões físicas do livro, sem transform: scale no StPageFlip. */
export type BookLayout = Readonly<{
  pageWidth: number;
  pageHeight: number;
}>;

export function calculateBookLayout(availableWidth: number, availableHeight: number, pageRatio: number, sizePercent = 100, visiblePages: 1 | 2 = 2): BookLayout {
  const scale = Math.max(0.65, Math.min(1, sizePercent / 100));
  const width = (Number.isFinite(availableWidth) ? Math.max(40, availableWidth - (visiblePages === 1 ? 18 : 48)) : 800) * scale;
  const height = (Number.isFinite(availableHeight) ? Math.max(40, availableHeight - 18) : 540) * scale;
  const ratio = Number.isFinite(pageRatio) ? Math.min(2.5, Math.max(0.25, pageRatio)) : 0.72;
  const pageHeight = Math.max(1, Math.floor(Math.min(1060, height, width / (visiblePages * ratio))));
  const pageWidth = Math.max(50, Math.floor(pageHeight * ratio));
  return { pageWidth, pageHeight };
}

/** Evita remontagem por oscilações de 1–2 px (scrollbar/fontes). */
export function shouldResizeBook(before: BookLayout, after: BookLayout): boolean {
  return Math.abs(before.pageWidth - after.pageWidth) >= 12 || Math.abs(before.pageHeight - after.pageHeight) >= 12;
}

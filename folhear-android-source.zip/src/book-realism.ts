/**
 * M2.1 — acabamento físico do livro.
 *
 * Estas camadas são puramente decorativas e ficam ATRÁS do elemento
 * que o StPageFlip controla. Nunca alteramos .book-page, o seu position,
 * os transforms, o z-index das folhas ou os eventos de arraste.
 */

export type BookThickness = Readonly<{
  left: number;
  right: number;
}>;

/** Espessura em pixels das pilhas de papel na borda externa do livro. */
export function calculateBookThickness(index: number, totalPages: number): BookThickness {
  if (totalPages <= 0 || !Number.isFinite(totalPages)) return { left: 1, right: 1 };
  const safeIndex = Number.isFinite(index) ? Math.max(0, Math.min(index, totalPages - 1)) : 0;
  // O começo do livro tem poucas folhas à esquerda e muitas à direita;
  // no fim, ocorre o oposto. Evita dimensões excessivas em PDFs longos.
  const progress = totalPages < 2 ? 0 : safeIndex / (totalPages - 1);
  const amount = Math.min(16, Math.max(6, Math.round(Math.sqrt(totalPages) * 0.75)));
  return {
    left: 1 + Math.round(progress * amount),
    right: 1 + Math.round((1 - progress) * amount),
  };
}

/** Cria a moldura de leitura sem inserir nada DENTRO das folhas animadas. */
export function createBookScene(width: number, height: number): HTMLDivElement {
  const scene = document.createElement('div');
  scene.className = 'book-scene';
  scene.style.width = `${width}px`;
  scene.style.height = `${height}px`;
  scene.setAttribute('aria-label', 'Livro aberto');

  const material = document.createElement('div');
  material.className = 'book-material';
  material.setAttribute('aria-hidden', 'true');

  const cover = document.createElement('div');
  cover.className = 'book-hardcover';
  const spine = document.createElement('div');
  spine.className = 'book-physical-spine';
  const leftStack = document.createElement('div');
  leftStack.className = 'book-paper-stack book-paper-stack-left';
  const rightStack = document.createElement('div');
  rightStack.className = 'book-paper-stack book-paper-stack-right';

  material.append(cover, spine, leftStack, rightStack);
  scene.appendChild(material);
  return scene;
}

export function applyBookThickness(scene: HTMLElement | null, index: number, totalPages: number): void {
  if (!scene) return;
  const thickness = calculateBookThickness(index, totalPages);
  scene.style.setProperty('--stack-left', `${thickness.left}px`);
  scene.style.setProperty('--stack-right', `${thickness.right}px`);
}

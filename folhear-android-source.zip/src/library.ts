/** Biblioteca offline em IndexedDB (WebView2/Tauri). Arquivos nunca são enviados à rede. */
export type BookRecord = {
  id: string;
  fileName: string;
  title: string;
  category: string;
  favorite: boolean;
  createdAt: number;
  openedAt: number;
  lastPage: number;
  totalPages: number;
  bookmarks: number[];
  preview?: string;
  cover?: string;
};

const DB_NAME = 'folhear-library-v1';
const DB_VERSION = 1;

function database(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('books')) db.createObjectStore('books', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('files')) db.createObjectStore('files', { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Banco local indisponível'));
    request.onblocked = () => reject(new Error('Feche outras janelas do Folhear e tente novamente.'));
  });
}

async function requestFromStore<T>(store: 'books' | 'files', mode: IDBTransactionMode, action: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await database();
  return new Promise<T>((resolve, reject) => {
    const transaction = db.transaction(store, mode);
    let output: T;
    const request = action(transaction.objectStore(store));
    request.onsuccess = () => { output = request.result; };
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => { db.close(); resolve(output); };
    transaction.onerror = () => { db.close(); reject(transaction.error || new Error('Falha ao gravar a biblioteca')); };
    transaction.onabort = () => { db.close(); reject(transaction.error || new Error('Gravação interrompida')); };
  });
}

export const listBooks = (): Promise<BookRecord[]> => requestFromStore<BookRecord[]>('books', 'readonly', s => s.getAll());
export const getBook = (id: string): Promise<BookRecord | undefined> => requestFromStore<BookRecord | undefined>('books', 'readonly', s => s.get(id));
export const putBook = (book: BookRecord): Promise<IDBValidKey> => requestFromStore<IDBValidKey>('books', 'readwrite', s => s.put(book));
export async function getBookFile(id: string): Promise<Blob | undefined> {
  const result = await requestFromStore<{ id: string; blob: Blob } | undefined>('files', 'readonly', s => s.get(id));
  return result?.blob;
}

/** Se a gravação falhar (cota cheia), a transação inteira é revertida. */
export async function importBookData(book: BookRecord, bytes: Uint8Array): Promise<void> {
  const db = await database();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(['files', 'books'], 'readwrite');
    tx.objectStore('files').put({ id: book.id, blob: new Blob([new Uint8Array(bytes)], { type: 'application/pdf' }) });
    tx.objectStore('books').put(book);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('Sem espaço para guardar o PDF')); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error('Importação interrompida')); };
  });
}

export async function removeBook(id: string): Promise<void> {
  const db = await database();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(['files', 'books'], 'readwrite');
    tx.objectStore('files').delete(id);
    tx.objectStore('books').delete(id);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('Não foi possível excluir')); };
  });
}

/** Cria uma chave estável baseada no arquivo para evitar duplicatas reais. */
export async function bookId(bytes: Uint8Array): Promise<string> {
  const copy = new Uint8Array(bytes);
  const digest = await crypto.subtle.digest('SHA-256', copy);
  return Array.from(new Uint8Array(digest)).map(value => value.toString(16).padStart(2, '0')).join('');
}

export function cleanBookTitle(name: string): string {
  return name.replace(/\.pdf$/i, '').replace(/[_]+/g, ' ')
    .replace(/(?:[ _-]+v\d+(?:[.-]\d+)*(?:\s*\(\d+\))?)$/i, '')
    .replace(/\s*\(\d+\)$/g, '').replace(/\s+/g, ' ').trim().slice(0, 120) || 'Livro sem título';
}

export type BookSort = 'recent' | 'title' | 'added';
export function organizeBooks(books: BookRecord[], query: string, category: string, favoritesOnly: boolean, sort: BookSort): BookRecord[] {
  const q = query.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  return books.filter(book => {
    const match = `${book.title} ${book.fileName} ${book.category}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    return match.includes(q) && (category === '' || book.category === category) && (!favoritesOnly || book.favorite);
  }).sort((a, b) => sort === 'title'
    ? a.title.localeCompare(b.title, 'pt-BR')
    : sort === 'added' ? b.createdAt - a.createdAt : b.openedAt - a.openedAt);
}

export function toggleBookmark(bookmarks: number[], index: number): number[] {
  return bookmarks.includes(index) ? bookmarks.filter(x => x !== index) : [...new Set([...bookmarks, index])].sort((a, b) => a - b);
}

import { PageFlip } from 'page-flip';
import { getDocument, GlobalWorkerOptions, type PDFDocumentProxy } from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { isTauri, invoke } from '@tauri-apps/api/core';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { PdfPageCache } from './pdf-page-cache';
import { PageSound } from './page-sound';
import { applyBookThickness, createBookScene } from './book-realism';
import { calculateBookLayout, shouldResizeBook, type BookLayout } from './book-layout';
import { shouldUseSinglePage, canAdvancePage } from './mobile-layout';
import { createCoverLayer, type CoverLayer } from './book-cover';
import { loadPage, savePage } from './preferences';
import { type BookRecord, type BookSort, bookId, cleanBookTitle, getBook, getBookFile, importBookData, listBooks, organizeBooks, putBook, removeBook, toggleBookmark } from './library';
import { DEFAULT_APPEARANCE, loadAppearance, saveAppearance, type Appearance } from './appearance';
import { coverFromFile, documentOutline, pdfCoverThumbnail, searchDocument } from './pdf-tools';
import './style.css';

GlobalWorkerOptions.workerSrc = workerUrl;

function elem<T extends HTMLElement>(id: string): T {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Elemento inexistente: ${id}`);
  return element as T;
}

const openBtn = elem<HTMLButtonElement>('openBtn');
const welcomeOpenBtn = elem<HTMLButtonElement>('welcomeOpenBtn');
const fullscreenBtn = elem<HTMLButtonElement>('fullscreenBtn');
const immersiveBtn = elem<HTMLButtonElement>('immersiveBtn');
const closeBookBtn = elem<HTMLButtonElement>('closeBookBtn');
const app = elem<HTMLElement>('app');
const fileInput = elem<HTMLInputElement>('fileInput');
const welcome = elem<HTMLElement>('welcome');
const reader = elem<HTMLElement>('reader');
const bookMount = elem<HTMLDivElement>('bookMount');
const readerHint = elem<HTMLDivElement>('readerHint');
const bookTitle = elem<HTMLElement>('bookTitle');
const filenameText = elem<HTMLElement>('readerFilename');
const pageDisplay = elem<HTMLElement>('pageDisplay');
const prevBtn = elem<HTMLButtonElement>('prevBtn');
const nextBtn = elem<HTMLButtonElement>('nextBtn');
const pageInput = elem<HTMLInputElement>('pageInput');
const goBtn = elem<HTMLButtonElement>('goBtn');
const pageJump = elem<HTMLFormElement>('pageJump');
const loadingOverlay = elem<HTMLDivElement>('loading');
const loadingText = elem<HTMLSpanElement>('loadingText');
const volumeSlider = elem<HTMLInputElement>('volumeSlider');
const volumeText = elem<HTMLElement>('volumeText');
const soundIcon = elem<HTMLElement>('soundIcon');
const toast = elem<HTMLDivElement>('toast');
const dropOverlay = elem<HTMLDivElement>('dropOverlay');

// Marcos M2.4 e M3: interface externa ao motor de folhas StPageFlip.
const libraryBtn = elem<HTMLButtonElement>('libraryBtn');
const libraryView = elem<HTMLElement>('library');
const libraryImportBtn = elem<HTMLButtonElement>('libraryImportBtn');
const librarySearch = elem<HTMLInputElement>('librarySearch');
const libraryCategory = elem<HTMLSelectElement>('libraryCategory');
const librarySort = elem<HTMLSelectElement>('librarySort');
const libraryFavorites = elem<HTMLInputElement>('libraryFavorites');
const libraryGrid = elem<HTMLDivElement>('libraryGrid');
const libraryCount = elem<HTMLDivElement>('libraryCount');
const appearanceBtn = elem<HTMLButtonElement>('appearanceBtn');
const appearancePanel = elem<HTMLElement>('appearancePanel');
const appearanceCloseBtn = elem<HTMLButtonElement>('appearanceCloseBtn');
const sceneSelect = elem<HTMLSelectElement>('sceneSelect');
const paperSelect = elem<HTMLSelectElement>('paperSelect');
const shadowSlider = elem<HTMLInputElement>('shadowSlider');
const shadowOutput = elem<HTMLOutputElement>('shadowOutput');
const bookSizeSlider = elem<HTMLInputElement>('bookSizeSlider');
const sizeOutput = elem<HTMLOutputElement>('sizeOutput');
const appearanceResetBtn = elem<HTMLButtonElement>('appearanceResetBtn');
const readerToolsBtn = elem<HTMLButtonElement>('readerToolsBtn');
const bookmarkBtn = elem<HTMLButtonElement>('bookmarkBtn');
const readerTools = elem<HTMLElement>('readerTools');
const toolsCloseBtn = elem<HTMLButtonElement>('toolsCloseBtn');
const toolsBookmarks = elem<HTMLDivElement>('toolsBookmarks');
const toolsIndex = elem<HTMLDivElement>('toolsIndex');
const toolsSearch = elem<HTMLDivElement>('toolsSearch');
const pdfSearchForm = elem<HTMLFormElement>('pdfSearchForm');
const pdfSearchInput = elem<HTMLInputElement>('pdfSearchInput');
const pdfSearchStatus = elem<HTMLDivElement>('pdfSearchStatus');
const pdfSearchResults = elem<HTMLDivElement>('pdfSearchResults');
const editBookDialog = elem<HTMLDialogElement>('editBookDialog');
const editBookForm = elem<HTMLFormElement>('editBookForm');
const editBookTitle = elem<HTMLInputElement>('editBookTitle');
const editBookCategory = elem<HTMLInputElement>('editBookCategory');
const editBookCover = elem<HTMLInputElement>('editBookCover');
const editCancelBtn = elem<HTMLButtonElement>('editCancelBtn');

let appearance: Appearance = loadAppearance();
let libraryRecords: BookRecord[] = [];
let currentRecord: BookRecord | null = null;
let editingBookId = '';
let searchEpoch = 0;
let libraryEpoch = 0;
let currentToolTab = 'bookmarks';

const sound = new PageSound();
volumeSlider.value = String(sound.getVolume());
volumeText.textContent = `${sound.getVolume()}%`;
soundIcon.textContent = sound.getVolume() === 0 ? '♩' : '♫';

let pageFlip: PageFlip | null = null;
let bookScene: HTMLDivElement | null = null;
let currentPdf: PDFDocumentProxy | null = null;
let cache: PdfPageCache | null = null;
let fingerprint = '';
let totalPages = 0;
let activeLoad = 0;
let opening = false;
let currentIndex = 0;
let toastTimer: ReturnType<typeof setTimeout> | undefined;
let ready = false;
let preparingId = 0;
let hasPlayedForTurn = false;
let pageAspectRatio = 0;
let builtLayout: BookLayout | null = null;
let builtSinglePage = false;
let viewEpoch = 0;
let resizeTimer: ReturnType<typeof setTimeout> | undefined;
let isTurning = false;
let immersive = false;
let revealTimer: ReturnType<typeof setTimeout> | undefined;
let coverLayer: CoverLayer | null = null;
let coverClosed = false;
let coverTransitioning = false;
let activeFileName = '';



function message(text: string): void {
  toast.textContent = text;
  toast.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add('hidden'), 5200);
}

function loading(on: boolean, label = 'Preparando as páginas…'): void {
  loadingText.textContent = label;
  loadingOverlay.classList.toggle('hidden', !on);
  openBtn.disabled = on;
  welcomeOpenBtn.disabled = on;
  opening = on;
}

function controls(active: boolean): void {
  ready = active;
  bookMount.classList.toggle('is-buffering', !active);
  readerHint.textContent = active
    ? '←  Use as setas ou arraste o canto da página  →'
    : 'Preparando as próximas folhas…';
  const canNavigate = active && !coverClosed && !coverTransitioning;
  prevBtn.disabled = !canNavigate || currentIndex <= 0;
  nextBtn.disabled = !canNavigate || currentIndex >= totalPages - (builtSinglePage ? 1 : 2);
  pageInput.disabled = !canNavigate;
  goBtn.disabled = !canNavigate;
  closeBookBtn.disabled = !active || coverClosed || coverTransitioning;
  closeBookBtn.textContent = coverClosed ? 'Livro fechado' : 'Fechar livro';
}

function updatePage(index: number): void {
  currentIndex = Math.min(Math.max(0, index), Math.max(0, totalPages - 1));
  // M2.1: acompanha a leitura sem tocar nas folhas do StPageFlip.
  applyBookThickness(bookScene, currentIndex, totalPages);
  const first = currentIndex + 1;
  const last = Math.min(currentIndex + (pageFlip?.getOrientation() === 'portrait' ? 1 : 2), totalPages);
  pageDisplay.textContent = first === last ? `${first} / ${totalPages}` : `${first}–${last} / ${totalPages}`;
  pageInput.value = String(first);
  prevBtn.disabled = !ready || coverClosed || coverTransitioning || currentIndex <= 0;
  nextBtn.disabled = !ready || coverClosed || coverTransitioning || currentIndex >= totalPages - (builtSinglePage ? 1 : 2);
  if (fingerprint) savePage(fingerprint, currentIndex);
  if (currentRecord) {
    currentRecord.lastPage = currentIndex;
    currentRecord.openedAt = Date.now();
    void putBook({ ...currentRecord }).catch(error => console.warn('Progresso não salvo:', error));
  }
  updateBookmarkButton();
}

// Fecha apenas as folhas e seu cache; o PDF continua aberto para redimensionar.
function clearBookView(): void {
  viewEpoch++;
  coverLayer?.dispose();
  coverLayer = null;
  coverTransitioning = false;
  preparingId++;
  ready = false;
  hasPlayedForTurn = false;
  isTurning = false;
  cache?.dispose();
  cache = null;
  if (pageFlip) {
    try { pageFlip.destroy(); } catch (error) { console.warn('Fechando páginas:', error); }
    pageFlip = null;
  }
  bookMount.replaceChildren();
  bookScene = null;
  builtLayout = null;
  builtSinglePage = false;
}

async function teardown(): Promise<void> {
  clearTimeout(resizeTimer);
  clearBookView();
  if (currentPdf) {
    try { await currentPdf.destroy(); } catch { /* leitor já fechado */ }
    currentPdf = null;
  }
  totalPages = 0;
  pageAspectRatio = 0;
  fingerprint = '';
}

/**
 * M2.2: reconstrói somente a apresentação quando a janela muda.
 * O StPageFlip continua recebendo dimensões FIXAS em pixels reais,
 * sem transform:scale, sem mexer nas folhas ou no algoritmo de virada.
 */
async function mountBookView(pdf: PDFDocumentProxy, requestedPage: number, token: number): Promise<void> {
  clearBookView();
  const epoch = viewEpoch;
  const singlePage = shouldUseSinglePage(bookMount.clientWidth, window.innerWidth, window.innerHeight);
  const layout = calculateBookLayout(bookMount.clientWidth, bookMount.clientHeight, pageAspectRatio, appearance.size, singlePage ? 1 : 2);
  builtLayout = layout;
  builtSinglePage = singlePage;
  const { pageWidth, pageHeight } = layout;
  const spreadWidth = pageWidth * (singlePage ? 1 : 2);
  const leafCount = Math.max(2, totalPages + (totalPages % 2));
  const leaves: HTMLDivElement[] = [];
  const frame = document.createElement('div');
  frame.className = 'book-frame';
  frame.style.width = `${spreadWidth}px`;
  frame.style.height = `${pageHeight}px`;
  const host = document.createElement('div');
  host.className = 'book-root';
  host.setAttribute('aria-label', 'Livro digital aberto');
  for (let i = 0; i < leafCount; i++) {
    const leaf = document.createElement('div');
    leaf.className = i >= totalPages ? 'book-page page-blank' : 'book-page';
    leaf.setAttribute('aria-label', i < totalPages ? `Página ${i + 1}` : 'Página em branco');
    leaves.push(leaf);
    host.appendChild(leaf);
  }
  frame.appendChild(host);
  const scene = createBookScene(spreadWidth, pageHeight);
  scene.classList.toggle('is-single-page', singlePage);
  scene.appendChild(frame);
  bookMount.appendChild(scene);
  bookScene = scene;
  applyBookThickness(scene, requestedPage, totalPages);
  // Uma capa 3D separada, IRMÃ do livro. Nenhum nó entra nas folhas StPageFlip.
  coverLayer = createCoverLayer(bookMount, pageWidth, pageHeight, activeFileName, coverClosed, () => void toggleBookCover(false), currentRecord?.title, currentRecord?.cover);

  const flip = new PageFlip(host, {
    width: pageWidth,
    height: pageHeight,
    size: 'fixed',
    autoSize: false,
    drawShadow: true,
    maxShadowOpacity: 0.40,
    showCover: false,
    usePortrait: singlePage,
    flippingTime: 770,
    startPage: requestedPage,
    mobileScrollSupport: false,
  });
  pageFlip = flip;
  const pageCache = new PdfPageCache(pdf, leaves, pageWidth);
  cache = pageCache;
  let initialized = false;
  flip.on('changeState', (event) => {
    if (token !== activeLoad || epoch !== viewEpoch || !initialized) return;
    const state = String(event.data);
    isTurning = state !== 'read';
    if (state === 'read') {
      hasPlayedForTurn = false;
      // Se a janela foi alterada durante um arraste, recalcular só depois.
      scheduleLayoutCheck(220);
    }
    if ((state === 'user_fold' || state === 'flipping') && !hasPlayedForTurn) {
      sound.play();
      hasPlayedForTurn = true;
    }
  });
  flip.on('flip', (event) => {
    if (token !== activeLoad || epoch !== viewEpoch || !initialized) return;
    const index = Number(event.data);
    updatePage(index);
    controls(false);
    const sequence = ++preparingId;
    void pageCache.prepareSpread(index).then(() => {
      if (token === activeLoad && epoch === viewEpoch && sequence === preparingId && pageCache.isPrepared(index)) {
        controls(true);
        updatePage(index);
        scheduleLayoutCheck(400);
      }
    }).catch((error) => {
      if (token === activeLoad && epoch === viewEpoch) {
        message(`Não foi possível preparar as páginas: ${String(error)}`);
        console.error('Erro ao preparar páginas:', error);
      }
    });
  });
  flip.loadFromHTML(leaves);
  const initial = flip.getCurrentPageIndex();
  await pageCache.prepareSpread(initial);
  if (token !== activeLoad || epoch !== viewEpoch) return;
  initialized = true;
  controls(true);
  updatePage(initial);
}

async function openPdf(bytes: Uint8Array, fileName: string, record: BookRecord | null = null): Promise<void> {
  const token = ++activeLoad;
  showSection('reader');
  searchEpoch++;
  currentRecord = record;
  readerTools.classList.add('hidden');
  loading(true, 'Abrindo o arquivo PDF…');
  controls(false);
  // Um novo PDF começa aberto; o comando de fechar é sempre opcional.
  coverClosed = false;
  activeFileName = fileName;
  filenameText.textContent = fileName;
  bookTitle.textContent = record?.title || cleanBookTitle(fileName);

  let pdf: PDFDocumentProxy | null = null;
  try {
    await teardown();
    if (token !== activeLoad) return;
    pdf = await getDocument({ data: bytes, useSystemFonts: true }).promise;
    if (token !== activeLoad) { await pdf.destroy(); return; }
    const firstPage = await pdf.getPage(1);
    const dimensions = firstPage.getViewport({ scale: 1 });
    pageAspectRatio = Math.max(0.05, dimensions.width / Math.max(1, dimensions.height));
    firstPage.cleanup();
    totalPages = pdf.numPages;
    currentPdf = pdf;
    pdf = null;
    fingerprint = currentPdf.fingerprints?.[0] || `${fileName}-${currentPdf.numPages}`;
    const savedIndex = record ? Math.max(0, Math.min(record.lastPage, totalPages - 1)) : loadPage(fingerprint, totalPages);
    if (record && record.totalPages !== totalPages) { record.totalPages = totalPages; void putBook({ ...record }); }
    loading(true, 'Renderizando as primeiras páginas…');
    await mountBookView(currentPdf, savedIndex, token);
    if (token !== activeLoad) return;
    message(savedIndex > 0 ? 'Livro aberto na última página lida.' : 'Livro pronto. Aproveite a leitura!');
    if (record && !record.preview) {
      const pdfAtStart = currentPdf;
      void pdfCoverThumbnail(pdfAtStart).then(async preview => {
        if (currentRecord?.id !== record.id || !preview) return;
        currentRecord.preview = preview;
        await putBook({ ...currentRecord });
      }).catch(() => undefined);
    }
  } catch (error) {
    if (pdf) await pdf.destroy().catch(() => undefined);
    if (token === activeLoad) {
      const detail = error instanceof Error ? error.message : String(error);
      message(`Não foi possível abrir o PDF. ${detail}`);
      console.error('Erro ao abrir PDF:', error);
      await teardown();
      currentRecord = null;
      showSection('welcome');
      bookTitle.textContent = 'Nenhum livro aberto';
      pageDisplay.textContent = '— / —';
    }
  } finally {
    if (token === activeLoad) {
      loading(false);
      scheduleLayoutCheck(380);
    }
  }
}

function scheduleLayoutCheck(delay = 500): void {
  clearTimeout(resizeTimer);
  if (!currentPdf || !pageFlip || reader.classList.contains('hidden')) return;
  resizeTimer = setTimeout(() => void resizeCurrentBook(), delay);
}

async function resizeCurrentBook(): Promise<void> {
  if (opening || !ready || isTurning || coverTransitioning || reader.classList.contains('hidden') || !currentPdf || !pageFlip || !builtLayout) return;
  const desiredSinglePage = shouldUseSinglePage(bookMount.clientWidth, window.innerWidth, window.innerHeight);
  const desired = calculateBookLayout(bookMount.clientWidth, bookMount.clientHeight, pageAspectRatio, appearance.size, desiredSinglePage ? 1 : 2);
  if (desiredSinglePage === builtSinglePage && !shouldResizeBook(builtLayout, desired)) return;
  const pdf = currentPdf;
  const token = activeLoad;
  const page = pageFlip.getCurrentPageIndex();
  loading(true, 'Ajustando o tamanho do livro…');
  controls(false);
  try {
    await mountBookView(pdf, page, token);
  } catch (error) {
    if (token === activeLoad) {
      console.error('Falha ao ajustar o livro:', error);
      message('Não foi possível reajustar o livro. Reabra o PDF para tentar novamente.');
    }
  } finally {
    if (token === activeLoad) loading(false);
  }
}

const bookResizeObserver = new ResizeObserver(() => scheduleLayoutCheck(450));
bookResizeObserver.observe(bookMount);
async function chooseFile(): Promise<void> {
  if (opening) return;
  // A janela do Tauri usa o seletor de arquivos do próprio Windows. O
  // objeto File escolhido pelo usuário não precisa de permissões globais
  // do sistema de arquivos, ao contrário de um caminho absoluto de disco.
  fileInput.click();
}

async function openBrowserFile(file: File): Promise<void> {
  if (!file.name.toLowerCase().endsWith('.pdf')) { message('Selecione um arquivo PDF.'); return; }
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    await importAndOpen(bytes, file.name);
  } catch (error) { message(`Erro ao importar: ${String(error)}`); }
}

function turn(direction: 'next' | 'prev'): void {
  if (!pageFlip || opening || !ready || coverClosed || coverTransitioning) return;
  if (direction === 'next' && canAdvancePage(currentIndex, totalPages, builtSinglePage)) pageFlip.flipNext('bottom');
  if (direction === 'prev' && currentIndex > 0) pageFlip.flipPrev('bottom');
}

function jumpTo(oneBasedPage: number): void {
  if (!pageFlip || opening || !ready || coverClosed || coverTransitioning || !Number.isInteger(oneBasedPage) || oneBasedPage < 1 || oneBasedPage > totalPages) {
    message(`Informe uma página entre 1 e ${totalPages}.`);
    return;
  }
  const target = oneBasedPage - 1;
  pageFlip.turnToPage(target);
  // O evento flip inicia a preparação antes de liberar o próximo gesto.
}

/** Fecha/abre visualmente a capa; o PDF e o PageFlip permanecem intactos. */
async function toggleBookCover(close: boolean): Promise<void> {
  if (!coverLayer || opening || !ready || isTurning || coverTransitioning || coverClosed === close) return;
  const layer = coverLayer;
  const epoch = viewEpoch;
  coverTransitioning = true;
  // Capa intercepta o mouse durante a transição, sem tocar no motor de páginas.
  if (close) coverClosed = true;
  controls(true);
  try {
    if (close) await layer.close();
    else await layer.open();
    if (epoch !== viewEpoch || coverLayer !== layer) return;
    if (!close) coverClosed = false;
  } finally {
    if (epoch === viewEpoch && coverLayer === layer) {
      coverTransitioning = false;
      controls(true);
      updatePage(currentIndex);
    }
  }
}

function setImmersive(next: boolean): void {
  immersive = next;
  app.classList.toggle('is-immersive', immersive);
  immersiveBtn.setAttribute('aria-pressed', String(immersive));
  immersiveBtn.textContent = immersive ? 'Sair do imersivo' : 'Modo imersivo';
  immersiveBtn.title = immersive ? 'Sair da leitura imersiva (Esc ou I)' : 'Leitura imersiva (I)';
  app.classList.remove('controls-visible');
  // No modo imersivo o tamanho realmente muda; não escalamos as folhas com CSS.
  scheduleLayoutCheck(180);
}

function revealControlsAtY(y: number): void {
  if (!immersive) return;
  clearTimeout(revealTimer);
  if (y >= window.innerHeight - 136) {
    app.classList.add('controls-visible');
  } else {
    revealTimer = setTimeout(() => {
      if (!document.querySelector('.toolbar:focus-within')) app.classList.remove('controls-visible');
    }, 260);
  }
}

async function toggleFullscreen(): Promise<void> {
  try {
    if (isTauri()) {
      const window = getCurrentWindow();
      await window.setFullscreen(!(await window.isFullscreen()));
    } else if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await document.documentElement.requestFullscreen();
    }
  } catch (error) { message(`Não foi possível alternar tela cheia: ${String(error)}`); }
}

// Libera o áudio durante o gesto real (antes do mousemove/user_fold).
// Eventos de mousemove não contam como ativação de áudio no Chromium.
document.addEventListener('pointerdown', () => sound.unlock(), { capture: true });
document.addEventListener('keydown', () => sound.unlock(), { capture: true });
openBtn.addEventListener('click', () => void chooseFile());
welcomeOpenBtn.addEventListener('click', () => void chooseFile());
fullscreenBtn.addEventListener('click', () => void toggleFullscreen());
immersiveBtn.addEventListener('click', () => setImmersive(!immersive));
closeBookBtn.addEventListener('click', () => void toggleBookCover(true));
document.addEventListener('pointermove', (event) => revealControlsAtY(event.clientY));
prevBtn.addEventListener('click', () => turn('prev'));
nextBtn.addEventListener('click', () => turn('next'));
fileInput.addEventListener('change', () => {
  const files = Array.from(fileInput.files || []);
  fileInput.value = '';
  if (files.length === 1) void openBrowserFile(files[0]);
  else if (files.length > 1) void importSeveralFiles(files);
});
pageJump.addEventListener('submit', (event) => {
  event.preventDefault();
  jumpTo(Number(pageInput.value));
  pageInput.blur();
});
volumeSlider.addEventListener('input', () => {
  sound.setVolume(Number(volumeSlider.value));
  volumeText.textContent = `${sound.getVolume()}%`;
  soundIcon.textContent = sound.getVolume() === 0 ? '♩' : '♫';
});

document.addEventListener('keydown', (event) => {
  const el = event.target;
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement) return;
  if (event.key === 'Escape' && immersive) { setImmersive(false); return; }
  if (event.key.toLowerCase() === 'b' && !event.ctrlKey && !event.altKey && !event.metaKey) { event.preventDefault(); void showLibrary(); return; }
  if (event.key.toLowerCase() === 'm' && !event.ctrlKey && !event.altKey && !event.metaKey) { event.preventDefault(); void markCurrentPage(); return; }
  if (event.key.toLowerCase() === 'c' && !event.ctrlKey && !event.altKey && !event.metaKey) { event.preventDefault(); void toggleBookCover(!coverClosed); return; }
  if (event.key.toLowerCase() === 'i' && !event.ctrlKey && !event.altKey && !event.metaKey) { event.preventDefault(); setImmersive(!immersive); return; }
  if (event.ctrlKey && event.key.toLowerCase() === 'o') {
    event.preventDefault();
    void chooseFile();
  } else if (event.key === 'ArrowRight') {
    event.preventDefault();
    turn('next');
  } else if (event.key === 'ArrowLeft') {
    event.preventDefault();
    turn('prev');
  } else if (event.key === 'F11') {
    event.preventDefault();
    void toggleFullscreen();
  }
});

// Arrastar PDFs funciona no modo navegador. No Tauri o botão nativo é o padrão.
let dragDepth = 0;
document.addEventListener('dragenter', (event) => {
  if (isTauri()) return;
  event.preventDefault();
  dragDepth++;
  dropOverlay.classList.remove('hidden');
});
document.addEventListener('dragover', (event) => {
  if (isTauri()) return;
  event.preventDefault();
});
document.addEventListener('dragleave', (event) => {
  if (isTauri()) return;
  event.preventDefault();
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) dropOverlay.classList.add('hidden');
});
document.addEventListener('drop', (event) => {
  if (isTauri()) return;
  event.preventDefault();
  dragDepth = 0;
  dropOverlay.classList.add('hidden');
  if (event.dataTransfer?.files?.[0]) openBrowserFile(event.dataTransfer.files[0]);
});


// --------------------------------------------------------------------------
// M2.4: aparência configurável, sem qualquer transformação nas folhas.
// --------------------------------------------------------------------------
function applyAppearance(): void {
  app.dataset.scene = appearance.scene;
  app.dataset.paper = appearance.paper;
  app.style.setProperty('--book-shadow-strength', String(appearance.shadow / 100));
  sceneSelect.value = appearance.scene;
  paperSelect.value = appearance.paper;
  shadowSlider.value = String(appearance.shadow);
  shadowOutput.textContent = `${appearance.shadow}%`;
  bookSizeSlider.value = String(appearance.size);
  sizeOutput.textContent = `${appearance.size}%`;
  saveAppearance(appearance);
}
function setAppearance(next: Appearance): void {
  const priorSize = appearance.size;
  appearance = next;
  applyAppearance();
  if (appearance.size !== priorSize) scheduleLayoutCheck(300);
}
applyAppearance();
appearanceBtn.addEventListener('click', () => appearancePanel.classList.toggle('hidden'));
appearanceCloseBtn.addEventListener('click', () => appearancePanel.classList.add('hidden'));
sceneSelect.addEventListener('change', () => setAppearance({ ...appearance, scene: sceneSelect.value as Appearance['scene'] }));
paperSelect.addEventListener('change', () => setAppearance({ ...appearance, paper: paperSelect.value as Appearance['paper'] }));
shadowSlider.addEventListener('input', () => setAppearance({ ...appearance, shadow: Number(shadowSlider.value) }));
bookSizeSlider.addEventListener('input', () => setAppearance({ ...appearance, size: Number(bookSizeSlider.value) }));
appearanceResetBtn.addEventListener('click', () => setAppearance({ ...DEFAULT_APPEARANCE }));

// --------------------------------------------------------------------------
// M3.1 + M3.2: biblioteca local, capas, favoritos, categorias e filtros.
// --------------------------------------------------------------------------
function showSection(section: 'welcome' | 'reader' | 'library'): void {
  welcome.classList.toggle('hidden', section !== 'welcome');
  reader.classList.toggle('hidden', section !== 'reader');
  libraryView.classList.toggle('hidden', section !== 'library');
  if (section !== 'reader') readerTools.classList.add('hidden');
}

async function refreshLibrary(): Promise<void> {
  const token = ++libraryEpoch;
  try {
    const records = await listBooks();
    if (token !== libraryEpoch) return;
    libraryRecords = records;
    const categories = [...new Set(records.map(b => b.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'pt-BR'));
    const chosen = libraryCategory.value;
    libraryCategory.replaceChildren(new Option('Todas as categorias', ''), ...categories.map(c => new Option(c, c)));
    libraryCategory.value = categories.includes(chosen) ? chosen : '';
    renderLibraryGrid();
  } catch (error) {
    libraryCount.textContent = `Biblioteca indisponível: ${String(error)}`;
    libraryGrid.replaceChildren();
    message('Não foi possível acessar a biblioteca local. Você ainda pode abrir um PDF.');
  }
}

function renderLibraryGrid(): void {
  const sorted = organizeBooks(libraryRecords, librarySearch.value, libraryCategory.value, libraryFavorites.checked, librarySort.value as BookSort);
  libraryCount.textContent = `${sorted.length} ${sorted.length === 1 ? 'livro' : 'livros'} ${sorted.length !== libraryRecords.length ? `de ${libraryRecords.length}` : ''}`;
  libraryGrid.replaceChildren();
  if (!sorted.length) {
    const empty = document.createElement('div');
    empty.className = 'library-empty';
    empty.textContent = libraryRecords.length ? 'Nenhum livro corresponde aos filtros.' : 'Sua estante ainda está vazia. Adicione seu primeiro PDF.';
    libraryGrid.append(empty);
    return;
  }
  for (const book of sorted) {
    const card = document.createElement('article'); card.className = 'library-card';
    const cover = document.createElement('button'); cover.type = 'button'; cover.className = 'library-card-cover';
    cover.title = `Continuar a leitura: ${book.title}`;
    if (book.cover || book.preview) {
      const img = document.createElement('img'); img.src = book.cover || book.preview || ''; img.alt = `Capa: ${book.title}`; img.loading = 'lazy';
      cover.append(img);
    } else { const label = document.createElement('span'); label.textContent = book.title; cover.append(label); }
    cover.addEventListener('click', () => void openFromLibrary(book.id));
    const title = document.createElement('button'); title.className = 'library-card-title'; title.type = 'button'; title.textContent = book.title;
    title.addEventListener('click', () => void openFromLibrary(book.id));
    const subtitle = document.createElement('div'); subtitle.className = 'library-card-caption';
    const page = Math.min(book.totalPages, book.lastPage + 1);
    subtitle.textContent = `${book.category || 'Sem categoria'} · ${book.totalPages ? `${page}/${book.totalPages} pág.` : 'Ainda não lido'}`;
    const actions = document.createElement('div'); actions.className = 'library-card-actions';
    const favorite = document.createElement('button'); favorite.type = 'button'; favorite.textContent = book.favorite ? '★' : '☆'; favorite.title = book.favorite ? 'Remover favorito' : 'Favoritar';
    favorite.setAttribute('aria-label', favorite.title);
    favorite.addEventListener('click', async () => {
      book.favorite = !book.favorite;
      try { await putBook({ ...book }); await refreshLibrary(); } catch (error) { message(String(error)); }
    });
    const edit = document.createElement('button'); edit.type = 'button'; edit.textContent = 'Editar';
    edit.addEventListener('click', () => editBook(book));
    const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = 'Excluir'; remove.className = 'danger-text';
    remove.addEventListener('click', async () => {
      if (!confirm(`Remover “${book.title}” da biblioteca? O arquivo PDF original não será apagado.`)) return;
      try { await removeBook(book.id); if (currentRecord?.id === book.id) currentRecord = null; await refreshLibrary(); }
      catch (error) { message(`Não foi possível excluir: ${String(error)}`); }
    });
    actions.append(favorite, edit, remove);
    card.append(cover, title, subtitle, actions);
    libraryGrid.append(card);
  }
}

async function showLibrary(): Promise<void> {
  if (opening) return;
  showSection('library');
  await refreshLibrary();
}

async function importAndOpen(bytes: Uint8Array, name: string): Promise<void> {
  let record: BookRecord | null = null;
  try {
    const id = await bookId(bytes);
    record = (await getBook(id)) || null;
    if (!record) {
      record = { id, fileName: name, title: cleanBookTitle(name), category: '', favorite: false,
        createdAt: Date.now(), openedAt: Date.now(), lastPage: 0, totalPages: 0, bookmarks: [] };
      await importBookData(record, bytes);
    }
  } catch (error) {
    // Não impedir leitura quando o IndexedDB está indisponível/sem espaço.
    message(`PDF será aberto, mas não foi guardado na biblioteca: ${String(error)}`);
    record = null;
  }
  await openPdf(bytes, name, record);
}

/** Importa uma seleção de arquivos de uma vez e mostra os resultados na biblioteca. */
async function importSeveralFiles(files: File[]): Promise<void> {
  if (opening) return;
  loading(true, `Importando ${files.length} arquivos…`);
  let imported = 0;
  let failed = 0;
  try {
    for (const file of files) {
      if (!file.name.toLowerCase().endsWith('.pdf')) { failed++; continue; }
      try {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const id = await bookId(bytes);
        if (!await getBook(id)) {
          const now = Date.now();
          const record: BookRecord = { id, fileName: file.name, title: cleanBookTitle(file.name), category: '', favorite: false,
            createdAt: now, openedAt: now, lastPage: 0, totalPages: 0, bookmarks: [] };
          await importBookData(record, bytes);
          imported++;
        }
      } catch (error) { console.warn('Falha de importação:', file.name, error); failed++; }
    }
  } finally { loading(false); }
  await showLibrary();
  message(`${imported} PDFs adicionados à biblioteca.${failed ? ` ${failed} falharam (verifique o armazenamento disponível).` : ''}`);
}

async function openFromLibrary(id: string): Promise<void> {
  if (opening) return;
  loading(true, 'Abrindo livro da biblioteca…');
  try {
    const record = await getBook(id);
    const file = await getBookFile(id);
    if (!record || !file) throw new Error('Arquivo não encontrado na biblioteca. Importe-o novamente.');
    const bytes = new Uint8Array(await file.arrayBuffer());
    await openPdf(bytes, record.fileName, record);
  } catch (error) { loading(false); message(`Erro ao abrir livro: ${String(error)}`); }
}

function editBook(book: BookRecord): void {
  editingBookId = book.id;
  editBookTitle.value = book.title;
  editBookCategory.value = book.category;
  editBookCover.value = '';
  editBookDialog.showModal();
}
editCancelBtn.addEventListener('click', () => editBookDialog.close());
editBookForm.addEventListener('submit', (event) => {
  event.preventDefault();
  void (async () => {
    try {
      const book = await getBook(editingBookId);
      if (!book) return;
      const title = editBookTitle.value.trim();
      if (!title) { message('Informe um título.'); return; }
      const newCover = editBookCover.files?.[0] ? await coverFromFile(editBookCover.files[0]) : undefined;
      book.title = title.slice(0, 120);
      book.category = editBookCategory.value.trim().slice(0, 40);
      if (newCover) book.cover = newCover;
      await putBook(book);
      if (currentRecord?.id === book.id) {
        currentRecord = book;
        bookTitle.textContent = book.title;
        coverLayer?.update(book.title, book.cover);
      }
      editBookDialog.close();
      await refreshLibrary();
    } catch (error) { message(`Não foi possível salvar: ${String(error)}`); }
  })();
});

libraryBtn.addEventListener('click', () => void showLibrary());
libraryImportBtn.addEventListener('click', () => void chooseFile());
for (const input of [librarySearch, libraryCategory, librarySort, libraryFavorites]) {
  input.addEventListener(input === librarySearch ? 'input' : 'change', () => renderLibraryGrid());
}

// --------------------------------------------------------------------------
// M3.3: marcadores, índice do PDF e busca textual, em painel separado.
// --------------------------------------------------------------------------
function updateBookmarkButton(): void {
  const saved = Boolean(currentRecord?.bookmarks.includes(currentIndex));
  bookmarkBtn.textContent = saved ? '★ Marcada' : '☆ Marcar';
  bookmarkBtn.disabled = !currentRecord || !ready || coverClosed;
  bookmarkBtn.title = currentRecord ? 'Marcar ou desmarcar esta página (M)' : 'Importe o PDF na biblioteca para guardar marcadores';
}
async function markCurrentPage(): Promise<void> {
  if (!currentRecord || !ready || coverClosed) return;
  const book = currentRecord;
  book.bookmarks = toggleBookmark(book.bookmarks, currentIndex);
  try { await putBook({ ...book }); updateBookmarkButton(); renderBookmarks(); }
  catch (error) { message(`Não foi possível salvar o marcador: ${String(error)}`); }
}
function renderBookmarks(): void {
  toolsBookmarks.replaceChildren();
  if (!currentRecord?.bookmarks.length) {
    toolsBookmarks.textContent = 'Nenhum marcador. Use ☆ Marcar ou a tecla M durante a leitura.';
    return;
  }
  for (const page of currentRecord.bookmarks) {
    const row = document.createElement('div'); row.className = 'tool-item';
    const button = document.createElement('button'); button.type = 'button'; button.textContent = `Página ${page + 1}`;
    button.addEventListener('click', () => jumpTo(page + 1));
    const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '×'; remove.title = 'Excluir marcador';
    remove.addEventListener('click', async () => {
      if (!currentRecord) return;
      currentRecord.bookmarks = toggleBookmark(currentRecord.bookmarks, page);
      await putBook({ ...currentRecord });
      updateBookmarkButton(); renderBookmarks();
    });
    row.append(button, remove); toolsBookmarks.append(row);
  }
}

async function renderOutline(): Promise<void> {
  toolsIndex.replaceChildren(); toolsIndex.textContent = 'Carregando índice…';
  const pdf = currentPdf; const epoch = viewEpoch;
  if (!pdf) return;
  try {
    const entries = await documentOutline(pdf);
    if (pdf !== currentPdf || epoch !== viewEpoch) return;
    toolsIndex.replaceChildren();
    if (!entries.length) { toolsIndex.textContent = 'Este PDF não possui um índice navegável.'; return; }
    for (const item of entries) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'outline-item';
      button.textContent = `${item.title}${item.pageIndex !== null ? ` · ${item.pageIndex + 1}` : ''}`;
      button.style.paddingLeft = `${12 + item.depth * 14}px`;
      button.disabled = item.pageIndex === null;
      button.addEventListener('click', () => { if (item.pageIndex !== null) jumpTo(item.pageIndex + 1); });
      toolsIndex.append(button);
    }
  } catch (error) { if (pdf === currentPdf) toolsIndex.textContent = `Não foi possível ler o índice: ${String(error)}`; }
}
function switchTool(tab: string): void {
  currentToolTab = tab;
  for (const button of readerTools.querySelectorAll<HTMLButtonElement>('[data-tool-tab]')) button.classList.toggle('selected', button.dataset.toolTab === tab);
  toolsBookmarks.classList.toggle('hidden', tab !== 'bookmarks');
  toolsIndex.classList.toggle('hidden', tab !== 'index');
  toolsSearch.classList.toggle('hidden', tab !== 'search');
  if (tab === 'bookmarks') renderBookmarks();
  if (tab === 'index') void renderOutline();
}
readerToolsBtn.addEventListener('click', () => {
  const willOpen = readerTools.classList.contains('hidden');
  readerTools.classList.toggle('hidden', !willOpen);
  if (willOpen) switchTool(currentToolTab);
});
toolsCloseBtn.addEventListener('click', () => { readerTools.classList.add('hidden'); searchEpoch++; });
bookmarkBtn.addEventListener('click', () => void markCurrentPage());
readerTools.querySelectorAll<HTMLButtonElement>('[data-tool-tab]').forEach(btn => btn.addEventListener('click', () => switchTool(btn.dataset.toolTab || 'bookmarks')));
pdfSearchForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const pdf = currentPdf;
  if (!pdf || pdfSearchInput.value.trim().length < 2) return;
  const query = pdfSearchInput.value.trim();
  const token = ++searchEpoch;
  pdfSearchResults.replaceChildren();
  pdfSearchStatus.textContent = 'Procurando no documento…';
  void searchDocument(pdf, query, () => token !== searchEpoch || pdf !== currentPdf, (page, total) => {
    if (token === searchEpoch) pdfSearchStatus.textContent = `Analisando página ${page} de ${total}…`;
  }).then(hits => {
    if (token !== searchEpoch || pdf !== currentPdf) return;
    pdfSearchStatus.textContent = `${hits.length} ${hits.length === 1 ? 'ocorrência' : 'ocorrências'} encontradas${hits.length === 150 ? ' (limite de exibição)' : ''}.`;
    for (const hit of hits) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'search-result';
      const title = document.createElement('strong'); title.textContent = `Página ${hit.pageIndex + 1}`;
      const snippet = document.createElement('span'); snippet.textContent = hit.snippet;
      button.append(title, snippet);
      button.addEventListener('click', () => jumpTo(hit.pageIndex + 1));
      pdfSearchResults.append(button);
    }
  }).catch(error => { if (token === searchEpoch) pdfSearchStatus.textContent = `Falha na busca: ${String(error)}`; });
});

// Ao iniciar, a biblioteca salva é apresentada (ou tela de boas-vindas vazia).
void listBooks().then(records => {
  libraryRecords = records;
  if (records.length && !currentPdf && !opening) void showLibrary();
}).catch(() => undefined);

// M3.4: PDF selecionado via "Abrir com Folhear" no Windows (instalador NSIS).
if (isTauri()) {
  void invoke<string | null>('startup_pdf_name').then(async name => {
    if (!name || opening || currentPdf) return;
    const buffer = await invoke<ArrayBuffer>('startup_pdf_bytes');
    await importAndOpen(new Uint8Array(buffer), name);
  }).catch(error => console.warn('Arquivo de abertura do Windows:', error));
}

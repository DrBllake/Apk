/** Folhear Android: uma página em celulares, duas em telas largas.
 * O modo é escolhido ANTES de criar o StPageFlip; nunca alteramos suas folhas
 * com transform/position CSS (regressão de transparência no Windows).
 */
export function shouldUseSinglePage(mountWidth: number, viewportWidth: number, viewportHeight: number): boolean {
  if (!Number.isFinite(mountWidth) || mountWidth <= 0) return true;
  return mountWidth < 820 || (viewportWidth < 1060 && viewportHeight > viewportWidth);
}

export function canAdvancePage(index: number, total: number, singlePage: boolean): boolean {
  return index < total - (singlePage ? 1 : 2);
}

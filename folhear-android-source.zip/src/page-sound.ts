import { loadVolume, saveVolume } from './preferences';

const samples = [
  '/sounds/page-turn-1.wav',
  '/sounds/page-turn-2.wav',
  '/sounds/page-turn-3.wav',
];

/**
 * O navegador permite áudio WebAudio após um gesto do usuário.
 * unlock() é chamado no pointerdown/keydown, ANTES do user_fold do StPageFlip.
 * Assim a folha faz barulho durante o arraste, e não só após soltar o mouse.
 */
export class PageSound {
  private volume = loadVolume();
  private cursor = 0;
  private context: AudioContext | null = null;
  private buffers: AudioBuffer[] = [];

  constructor() {
    if (typeof AudioContext !== 'undefined') {
      this.context = new AudioContext();
      void Promise.all(samples.map(async (url) => {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Áudio indisponível: ${url}`);
        return this.context!.decodeAudioData(await response.arrayBuffer());
      })).then((buffers) => { this.buffers = buffers; }).catch((err) => {
        console.warn('Não foi possível carregar o som das páginas:', err);
      });
    }
  }

  getVolume(): number { return this.volume; }

  setVolume(value: number): void {
    this.volume = Math.max(0, Math.min(100, value));
    saveVolume(this.volume);
  }

  unlock(): void {
    if (this.context?.state === 'suspended') {
      void this.context.resume().catch((err) => console.warn('Não foi possível ativar o áudio:', err));
    }
  }

  play(): void {
    if (!this.volume || !this.context || this.context.state !== 'running' || !this.buffers.length) return;
    const buffer = this.buffers[this.cursor++ % this.buffers.length];
    const source = this.context.createBufferSource();
    const gain = this.context.createGain();
    gain.gain.value = (this.volume / 100) * 0.75;
    source.buffer = buffer;
    source.connect(gain).connect(this.context.destination);
    source.start();
  }
}

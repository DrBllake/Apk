import type { PDFDocumentProxy } from 'pdfjs-dist';

/**
 * Cache de páginas para StPageFlip.
 *
 * IMPORTANTE: uma virada em modo livro usa quatro faces:
 * - duas páginas visíveis agora;
 * - o verso da folha e a página que ficará por baixo dela.
 *
 * Por isso prepareSpread() só libera o gesto depois que a dupla atual
 * E as duas duplas adjacentes estão realmente desenhadas.
 */
export class PdfPageCache {
  private readonly rendered = new Set<number>();
  private readonly pending = new Map<number, Promise<void>>();
  private readonly tasks: Array<{ index: number; resolve: () => void; reject: (error: unknown) => void }> = [];
  private active = 0;
  private center = 0;
  private disposed = false;
  private readonly maxSimultaneous = 2;

  constructor(
    private readonly pdf: PDFDocumentProxy,
    private readonly leaves: HTMLDivElement[],
    private readonly pageWidth: number,
  ) {}

  /**
   * Bloqueia a leitura até que o conteúdo que aparece ao puxar a folha
   * (em ambos os sentidos) esteja pronto e com a página correta.
   */
  async prepareSpread(index: number): Promise<void> {
    if (this.disposed) return;
    const first = Math.max(0, index - (index % 2));
    this.center = first;

    // Ordem importa: dupla atual, frente da virada e páginas anteriores.
    const required = [first, first + 1, first + 2, first + 3, first - 2, first - 1]
      .filter((i) => i >= 0 && i < this.pdf.numPages);

    await Promise.all(required.map((page) => this.request(page)));
    if (this.disposed || this.center !== first) return;
    // Descarta apenas depois de preparar, nunca no meio de um gesto.
    this.evictDistant(first);
  }

  isPrepared(index: number): boolean {
    const first = Math.max(0, index - (index % 2));
    return [first, first + 1, first + 2, first + 3, first - 2, first - 1]
      .filter((i) => i >= 0 && i < this.pdf.numPages)
      .every((i) => this.rendered.has(i));
  }

  private request(index: number): Promise<void> {
    if (this.disposed || this.rendered.has(index)) return Promise.resolve();
    const existing = this.pending.get(index);
    if (existing) return existing;

    let resolve!: () => void;
    let reject!: (error: unknown) => void;
    const promise = new Promise<void>((yes, no) => { resolve = yes; reject = no; });
    this.pending.set(index, promise);
    this.tasks.push({ index, resolve, reject });
    this.pump();
    return promise;
  }

  private pump(): void {
    while (!this.disposed && this.active < this.maxSimultaneous && this.tasks.length) {
      const task = this.tasks.shift()!;
      this.active++;
      void this.paint(task.index)
        .then(task.resolve, task.reject)
        .finally(() => {
          this.pending.delete(task.index);
          this.active--;
          this.pump();
        });
    }
  }

  private async paint(index: number): Promise<void> {
    if (this.disposed || Math.abs(this.center - index) > 9) return;
    const pdfPage = await this.pdf.getPage(index + 1);
    if (this.disposed || Math.abs(this.center - index) > 9) return;

    const unscaled = pdfPage.getViewport({ scale: 1 });
    const pixels = Math.min(1800, Math.max(900,
      Math.round(this.pageWidth * Math.min(window.devicePixelRatio || 1, 2))));
    const viewport = pdfPage.getViewport({ scale: pixels / unscaled.width });
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(viewport.width));
    canvas.height = Math.max(1, Math.round(viewport.height));
    canvas.className = 'pdf-page-canvas';
    canvas.setAttribute('aria-label', `Página ${index + 1}`);
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error(`Falha ao desenhar a página ${index + 1}.`);

    await pdfPage.render({ canvas, canvasContext: context, viewport }).promise;
    pdfPage.cleanup();

    if (this.disposed || Math.abs(this.center - index) > 9) {
      canvas.width = 0;
      canvas.height = 0;
      return;
    }
    // Preserva a folha: o StPageFlip mantém uma referência a este elemento.
    this.leaves[index].replaceChildren(canvas);
    this.rendered.add(index);
  }

  private evictDistant(center: number): void {
    for (const index of this.rendered) {
      if (Math.abs(index - center) <= 7) continue;
      const canvas = this.leaves[index].querySelector('canvas');
      if (canvas) { canvas.width = 0; canvas.height = 0; }
      this.leaves[index].replaceChildren();
      this.rendered.delete(index);
    }
  }

  dispose(): void {
    this.disposed = true;
    for (const task of this.tasks) task.resolve();
    this.tasks.length = 0;
    for (const leaf of this.leaves) leaf.replaceChildren();
    this.rendered.clear();
  }
}

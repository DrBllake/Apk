import type { PDFDocumentProxy } from 'pdfjs-dist';
export type OutlineEntry = { title: string; pageIndex: number | null; depth: number };
export type SearchHit = { pageIndex: number; snippet: string };

export function normalizedText(value: string): string {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
}
export function excerpt(value: string, start: number, length: number): string {
  return `${start > 46 ? '…' : ''}${value.slice(Math.max(0, start - 46), start + Math.max(80, length + 58)).replace(/\s+/g, ' ').trim()}…`;
}
export async function documentOutline(pdf: PDFDocumentProxy): Promise<OutlineEntry[]> {
  const outline = await pdf.getOutline();
  const entries: OutlineEntry[] = [];
  if (!outline) return entries;
  async function traverse(items: typeof outline, depth: number): Promise<void> {
    if (depth > 9 || entries.length >= 350) return;
    for (const item of items) {
      if (entries.length >= 350) break;
      let index: number | null = null;
      try {
        const dest = typeof item.dest === 'string' ? await pdf.getDestination(item.dest) : item.dest;
        if (dest && dest.length) {
          const ref = dest[0];
          index = typeof ref === 'number' ? ref : await pdf.getPageIndex(ref);
        }
      } catch { /* Destino sem página navegável */ }
      entries.push({ title: item.title || 'Seção sem título', pageIndex: index, depth });
      if (item.items.length) await traverse(item.items, depth + 1);
    }
  }
  await traverse(outline, 0);
  return entries;
}
export async function searchDocument(pdf: PDFDocumentProxy, query: string, cancelled: () => boolean, onProgress?: (page: number, total: number) => void): Promise<SearchHit[]> {
  const needle = normalizedText(query).trim();
  if (!needle || needle.length < 2) return [];
  const hits: SearchHit[] = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
    if (cancelled()) break;
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    const text = content.items.map((item: { str?: string }) => item.str || '').join(' ');
    const source = normalizedText(text);
    let from = 0;
    let count = 0;
    while (hits.length < 150 && count < 3) {
      const at = source.indexOf(needle, from);
      if (at === -1) break;
      hits.push({ pageIndex: pageNumber - 1, snippet: excerpt(text, at, needle.length) });
      from = at + Math.max(needle.length, 1);
      count++;
    }
    onProgress?.(pageNumber, pdf.numPages);
  }
  return hits;
}
export async function pdfCoverThumbnail(pdf: PDFDocumentProxy): Promise<string> {
  const page = await pdf.getPage(1);
  const viewport = page.getViewport({ scale: 1 });
  const scale = Math.min(0.75, 240 / viewport.width);
  const target = page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(target.width));
  canvas.height = Math.max(1, Math.round(target.height));
  const context = canvas.getContext('2d');
  if (!context) return '';
  await page.render({ canvas, canvasContext: context, viewport: target }).promise;
  return canvas.toDataURL('image/jpeg', 0.73);
}
/** Reduz capa importada para não ocupar megabytes no banco de dados. */
export async function coverFromFile(file: File): Promise<string> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 12_000_000) throw new Error('Selecione JPG, PNG ou WebP com até 12 MB.');
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
    const factor = Math.min(1, 600 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(image.naturalWidth * factor));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * factor));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas indisponível');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.83);
  } finally { URL.revokeObjectURL(url); }
}

const PREFIX = 'folhear:marco1:';

export function loadVolume(): number {
  try {
    const stored = localStorage.getItem(`${PREFIX}volume`);
    if (stored === null) return 45;
    const value = Number(stored);
    if (Number.isFinite(value) && value >= 0 && value <= 100) return value;
  } catch { /* modo privado */ }
  return 45;
}

export function saveVolume(volume: number): void {
  try { localStorage.setItem(`${PREFIX}volume`, String(volume)); } catch { /* sem armazenamento */ }
}

function bookKey(fingerprint: string): string {
  return `${PREFIX}book:${fingerprint}:page`;
}

export function loadPage(fingerprint: string, total: number): number {
  try {
    const value = Number(localStorage.getItem(bookKey(fingerprint)));
    if (Number.isInteger(value) && value >= 0 && value < total) return value;
  } catch { /* sem armazenamento */ }
  return 0;
}

export function savePage(fingerprint: string, index: number): void {
  try { localStorage.setItem(bookKey(fingerprint), String(index)); } catch { /* sem armazenamento */ }
}

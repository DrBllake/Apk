import test from 'node:test';
import assert from 'node:assert/strict';
import { validateAppearance, DEFAULT_APPEARANCE } from '../src/appearance.ts';
test('preferências inválidas usam padrão', () => {
  assert.deepEqual(validateAppearance({scene:'unknown',paper:'rainbow',size:1000,shadow:-30}), {...DEFAULT_APPEARANCE, size:100, shadow:0});
});
test('preferências válidas preservadas', () => {
  assert.deepEqual(validateAppearance({scene:'wood',paper:'sepia',shadow:67,size:85}), {scene:'wood',paper:'sepia',shadow:67,size:85});
});

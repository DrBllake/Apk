import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { coverDisplayTitle, COVER_ANIMATION_MS } from '../src/book-cover.ts';

test('título de capa elimina somente extensão e sublinhados', () => {
  assert.equal(coverDisplayTitle('A_Mao_da_Princesa_v4-2 (1).pdf'), 'A Mao da Princesa');
  assert.equal(coverDisplayTitle('   .pdf'), 'Meu livro');
  assert.ok(coverDisplayTitle('x'.repeat(200)).length <= 90);
});
test('animação não requer alterar o motor de páginas', () => {
  assert.equal(COVER_ANIMATION_MS, 820);
  const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
  const main = fs.readFileSync(new URL('../src/main.ts', import.meta.url), 'utf8');
  assert.match(css, /\.book-page\s*\{[^}]*position:absolute/);
  assert.match(css, /\.book-cover-screen\s*\{[^}]*position:\s*absolute/);
  assert.match(main, /showCover:\s*false/);
  assert.match(main, /usePortrait:\s*singlePage/); // Android usa 1 página; Windows mantém a dupla
  assert.match(main, /flip\.loadFromHTML\(leaves\)/);
  assert.match(main, /coverLayer\s*=\s*createCoverLayer\(/);
});
test('tampa do livro só envolve elementos irmãos das páginas', () => {
  const source = fs.readFileSync(new URL('../src/main.ts', import.meta.url), 'utf8');
  const fragment = source.split('const flip = new PageFlip(host, {')[0];
  assert.ok(fragment.indexOf('bookMount.appendChild(scene)') < fragment.indexOf('createCoverLayer(bookMount'));
  assert.doesNotMatch(fragment, /host\.appendChild\(cover/);
});

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { calculateBookLayout, shouldResizeBook } from '../src/book-layout.ts';

const dir = path.dirname(fileURLToPath(import.meta.url));
const css = readFileSync(path.join(dir, '../src/style.css'), 'utf8');
const main = readFileSync(path.join(dir, '../src/main.ts'), 'utf8');

test('o livro cabe na largura e altura da área disponível com margem', () => {
  for (const ratio of [0.62, 0.7, 1, 1.6]) {
    for (const [width, height] of [[1400,650],[800,530],[1700,920],[590,390],[260,240]]) {
      const rect = calculateBookLayout(width,height,ratio);
      assert.ok(rect.pageHeight <= height-18);
      assert.ok(2*rect.pageWidth <= width-48);
      assert.ok(rect.pageHeight > 0 && rect.pageWidth > 0);
    }
  }
});

test('ao aumentar a janela, o livro cresce; fullscreen cresce mais', () => {
  const before = calculateBookLayout(1380,600,0.70);
  const after = calculateBookLayout(1580,880,0.70);
  assert.ok(after.pageHeight > before.pageHeight);
  assert.ok(after.pageWidth > before.pageWidth);
});

test('mudanças muito pequenas não provocam remontagem constante', () => {
  assert.equal(shouldResizeBook({pageWidth:400,pageHeight:600},{pageWidth:406,pageHeight:606}), false);
  assert.equal(shouldResizeBook({pageWidth:400,pageHeight:600},{pageWidth:430,pageHeight:660}), true);
});

test('CSS protege a animação e não aplica scale às folhas', () => {
  assert.match(css, /\.book-page\s*\{[^}]*position:\s*absolute;/);
  assert.doesNotMatch(css, /\.book-page\s*\{[^}]*position:\s*relative;/);
  assert.doesNotMatch(css, /\.book-scene[^\{]*\{[^}]*transform:\s*scale/);
  assert.match(main, /const layout = calculateBookLayout/);
  assert.match(main, /const page = pageFlip.getCurrentPageIndex\(\)/);
  assert.match(main, /size: 'fixed'/);
});

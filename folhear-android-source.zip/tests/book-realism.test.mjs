import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { calculateBookThickness } from '../src/book-realism.ts';

const dir = path.dirname(fileURLToPath(import.meta.url));
const css = readFileSync(path.join(dir, '../src/style.css'), 'utf8');
const main = readFileSync(path.join(dir, '../src/main.ts'), 'utf8');

test('pilha esquerda cresce ao longo do livro; direita diminui', () => {
  const start = calculateBookThickness(0, 293);
  const middle = calculateBookThickness(146, 293);
  const end = calculateBookThickness(292, 293);
  assert.ok(start.left < middle.left && middle.left < end.left);
  assert.ok(start.right > middle.right && middle.right > end.right);
  assert.ok(start.left >= 1 && end.right >= 1);
});

test('livros muito longos têm espessura limitada', () => {
  const start = calculateBookThickness(0, 20_000);
  const end = calculateBookThickness(19_999, 20_000);
  assert.ok(start.right <= 17);
  assert.ok(end.left <= 17);
});

test('índices fora do intervalo não criam espessura inválida', () => {
  assert.deepEqual(calculateBookThickness(-5, 0), {left:1, right:1});
  assert.deepEqual(calculateBookThickness(Number.NaN, 0), {left:1, right:1});
  assert.deepEqual(calculateBookThickness(-999, 100), calculateBookThickness(0, 100));
  assert.deepEqual(calculateBookThickness(999, 100), calculateBookThickness(99, 100));
});

test('regra absoluta das páginas corrigida permanece intocada', () => {
  assert.match(css, /\.book-page\s*\{[^}]*position:\s*absolute;/);
  assert.doesNotMatch(css, /\.book-page\s*\{[^}]*position:\s*relative;/);
  assert.match(css, /\.book-scene\s*>\s*\.book-frame/);
  assert.match(css, /\.book-material\s*\{[^}]*pointer-events:\s*none;/);
});

test('elementos físicos ficam fora do host do StPageFlip', () => {
  assert.match(main, /frame\.appendChild\(host\);[\s\S]*?scene\.appendChild\(frame\);[\s\S]*?bookMount\.appendChild\(scene\);/);
  assert.match(main, /flip\.loadFromHTML\(leaves\)/);
  assert.match(main, /applyBookThickness\(bookScene, currentIndex, totalPages\)/);
});

'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const project = path.join(__dirname, '..');
const src = fs.readFileSync(path.join(project, 'src/pdf-page-cache.ts'), 'utf8');
const compiled = ts.transpileModule(src, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } });
const moduleObject = { exports: {} };
const context = { module: moduleObject, exports: moduleObject.exports, console, window: { devicePixelRatio: 1 }, document: {
  createElement: (type) => {
    assert.equal(type, 'canvas');
    return { width: 0, height: 0, className: '', setAttribute() {}, getContext() { return {}; } };
  },
}};
vm.runInNewContext(compiled.outputText, context, { filename: 'cache.js' });
const { PdfPageCache } = moduleObject.exports;

const leaves = Array.from({ length: 28 }, () => ({
  child: null,
  replaceChildren(...nodes) { this.child = nodes[0] || null; },
  querySelector(type) { return type === 'canvas' ? this.child : null; },
}));
let active = 0;
let maxActive = 0;
const rendered = [];
const pdf = {
  numPages: 28,
  async getPage(i) {
    return {
      getViewport({ scale }) { return { width: 400 * scale, height: 620 * scale }; },
      render() {
        active++;
        maxActive = Math.max(maxActive, active);
        return { promise: new Promise((resolve) => setTimeout(() => {
          rendered.push(i);
          active--;
          resolve();
        }, 1)) };
      },
      cleanup() {},
    };
  },
};

async function run() {
  const cache = new PdfPageCache(pdf, leaves, 400);
  await cache.prepareSpread(0);
  assert(cache.isPrepared(0), 'Primeira dupla precisa ter a proxima dupla pronta');
  assert.deepEqual(rendered.slice().sort((a, b) => a - b), [1, 2, 3, 4]);
  assert(leaves[2].child, 'Verso da proxima folha deve existir antes do arraste');
  assert(leaves[3].child, 'Pagina sob a folha deve existir antes do arraste');
  await cache.prepareSpread(2);
  assert(cache.isPrepared(2), 'Conteudo das paginas 3–4 e adjacentes deve estar pronto');
  assert(leaves[4].child && leaves[5].child, 'Proxima dupla deve estar pronta antes do arraste');
  assert(maxActive <= 2, 'No maximo duas paginas devem ser renderizadas ao mesmo tempo');
  await cache.prepareSpread(20);
  assert(cache.isPrepared(20), 'Salto de pagina deve carregar as duplas adjacentes');
  assert.equal(leaves[0].child, null, 'Paginas distantes devem ser descartadas');
  cache.dispose();
  assert.equal(leaves[20].child, null, 'Dispose deve liberar os canvases');
  console.log('OK: pre-renderizacao do verso e da pagina inferior, saltos, limite de concorrencia e descarte.');
}
run().catch((error) => { console.error(error); process.exitCode = 1; });

import test from 'node:test';
import assert from 'node:assert/strict';
import { cleanBookTitle, organizeBooks, toggleBookmark } from '../src/library.ts';
const base = (id, title, category, favorite, createdAt, openedAt) => ({id, title, category, favorite, createdAt, openedAt, bookmarks:[],fileName:title+'.pdf',lastPage:0,totalPages:20});
test('limpa nomes de arquivo sem alterar o nome literário', () => {
  assert.equal(cleanBookTitle('A_Mao_da_Princesa_v4-2 (1).pdf'), 'A Mao da Princesa');
  assert.equal(cleanBookTitle('História_da_Morte.pdf'), 'História da Morte');
});
test('organiza por favoritos, categoria, texto acentuado e ordenação', () => {
  const books = [base('a','Árvore','Fantasia',true,1,5),base('b','Brisa','Poesia',false,2,4),base('c','Casa','Fantasia',true,3,10)];
  assert.deepEqual(organizeBooks(books,'arvore','Fantasia',true,'title').map(b=>b.id), ['a']);
  assert.deepEqual(organizeBooks(books,'','',true,'recent').map(b=>b.id), ['c','a']);
  assert.deepEqual(organizeBooks(books,'','',false,'added').map(b=>b.id), ['c','b','a']);
});
test('marca e desmarca a mesma página, sem duplicatas', () => {
  assert.deepEqual(toggleBookmark([8,2], 4), [2,4,8]);
  assert.deepEqual(toggleBookmark([2,4,8], 4), [2,8]);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { shouldUseSinglePage, canAdvancePage } from '../src/mobile-layout.ts';
import { calculateBookLayout } from '../src/book-layout.ts';
import { readFileSync } from 'node:fs';

test('celular retrato e tablet retrato usam uma página', () => {
  assert.equal(shouldUseSinglePage(370, 393, 852), true);
  assert.equal(shouldUseSinglePage(720, 800, 1100), true);
});
test('desktop e tablet largo continuam duas páginas', () => {
  assert.equal(shouldUseSinglePage(1200, 1440, 900), false);
});
test('última página do livro no modo retrato é alcançável', () => {
  assert.equal(canAdvancePage(291, 293, true), true);
  assert.equal(canAdvancePage(292, 293, true), false);
  assert.equal(canAdvancePage(291, 293, false), false);
});
test('layout retrato cabe na tela sem reduzir página como dupla', () => {
  const one = calculateBookLayout(393, 650, 0.72, 100, 1);
  const two = calculateBookLayout(393, 650, 0.72, 100, 2);
  assert.ok(one.pageHeight > two.pageHeight);
  assert.ok(one.pageWidth <= 393);
});
test('posicionamento original das folhas continua absoluto', () => {
  const css = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
  assert.match(css, /\.book-page\s*\{[^}]*position\s*:\s*absolute/s);
  assert.doesNotMatch(css.split('FOLHEAR ANDROID — INTERFACE TOUCH')[1], /\.book-page\s*\{/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizedText, excerpt } from '../src/pdf-tools.ts';
test('busca trata maiúsculas e acentos', () => {
  assert.equal(normalizedText('Amélia'), 'amelia');
  assert.ok(normalizedText('CAPÍTULO DO LIVRO').includes('capitulo'));
});
test('recorte de busca preserva texto legível', () => {
  assert.ok(excerpt('A princesa caminhava pela estrada', 2, 8).includes('princesa'));
});

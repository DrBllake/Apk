import { defineConfig } from 'vite';

export default defineConfig({
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: '127.0.0.1',
    // Vite so precisa monitorar os arquivos da interface. O cargo/Tauri
    // ja acompanha os arquivos Rust. Monitorar as DLLs e EXEs criados
    // em src-tauri/target provoca EBUSY no Windows durante a compilacao.
    watch: {
      ignored: (watchPath: string) => {
        const normalized = watchPath.replace(/\\/g, '/');
        return /(?:^|\/)src-tauri(?:\/|$)/.test(normalized);
      },
    },
  },
  build: { target: 'es2022' },
});
